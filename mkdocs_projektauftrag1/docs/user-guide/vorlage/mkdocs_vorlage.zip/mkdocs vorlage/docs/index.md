# Willkommen

Dies ist eine Dokumentation.

!!! quote "Ein Zitat"
    Markdown ist sehr flexibel.

## Die Basics...

Der Text ist *kursiv*, dieser **fett**

Eine Tabelle:

|Kopfzeile|Kopfzeile|
|---|---|
|Zelle|Zelle|

[... im Internet](https://www.markdownguide.org/basic-syntax/)

---

Zum [Impressum](legal/imprint.md).
​

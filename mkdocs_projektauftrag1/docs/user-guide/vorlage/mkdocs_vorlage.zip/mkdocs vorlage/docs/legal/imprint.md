# Impressum

<h2>Ein MkDocs-Template</h2>

für die **Integration** der MkDocs-Applikation  
in die schulische (IT-)Projektorganisation  
in den Unterricht am BSZET Dresden. 

![impressum](images/impressum.jpg)

<h2>erstellt von</h2>

Fachbereich IT-Systeme

BSZ Elektrotechnik Dresden  
01219 Dresden  
Strehlener Platz 2

*&copy; 2021*



